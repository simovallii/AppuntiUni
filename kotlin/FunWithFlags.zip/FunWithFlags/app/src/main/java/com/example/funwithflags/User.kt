package com.example.funwithflags

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "User")
data class User(
    @PrimaryKey(autoGenerate = true) val _id: Int = 0,
    @ColumnInfo(name = "username") val name: String?,
    @ColumnInfo("score") val score: Int?,
    @ColumnInfo("bestScore") val bestScore: Int?=0
)

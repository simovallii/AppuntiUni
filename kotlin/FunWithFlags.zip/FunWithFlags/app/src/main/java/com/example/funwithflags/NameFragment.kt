package com.example.funwithflags

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


class NameFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_name, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val editText = view.findViewById<EditText>(R.id.editTextName)
        val button = view.findViewById<Button>(R.id.buttonStart)


        button.setOnClickListener {
            val name = editText.text.toString()
            val newUser = User(name = name, score = 0, bestScore = 0)
            val dbDAO = (activity as MainActivity).dbDAO
            val myCoroutineScope = (activity as MainActivity).myCoroutineScope

            myCoroutineScope.launch {
                val existingUser = dbDAO.getByName(name)
                if (existingUser == null) {
                    dbDAO.insert(newUser)  // nuovo utente
                } else {
                    dbDAO.update(existingUser.copy(score = 0))  // resetta solo lo score, bestScore rimane
                }
                withContext(Dispatchers.Main) {
                    val action = NameFragmentDirections.actionNameFragmentToLevel1Fragment(name)
                    findNavController().navigate(action)
                }
            }
        }
    }
}

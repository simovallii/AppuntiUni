package com.example.funwithflags

enum class Question {
    COUNTRY_FROM_FLAG,    // Qual è il paese rappresentato da questa bandiera?
    CAPITAL_FROM_FLAG,    // Qual è la capitale della città rappresentata dalla bandiera?
    CAPITAL_FROM_COUNTRY  // Qual è la capitale di [Paese]?
}

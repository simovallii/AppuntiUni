package com.example.funwithflags

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Button
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import android.widget.LinearLayout
import kotlinx.coroutines.withContext

class EndFragment : Fragment() {

    val args: EndFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_end, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val playerName = args.playerName
        val score = args.score
        val dbDAO = (activity as MainActivity).dbDAO
        val scope = (activity as MainActivity).myCoroutineScope

        val textEnd = view.findViewById<TextView>(R.id.textEnd)
        when (score) {
            0 -> textEnd.text = "Oh no! Hai totalizzato $score punti! "
            1 -> textEnd.text = "Bravo! Hai totalizzato $score punto! "
            else -> textEnd.text = "Bravo! Hai totalizzato $score punti! "

        }


        val layout = view.findViewById<LinearLayout>(R.id.layoutClassifica)

        scope.launch {
            val user = dbDAO.getByName(playerName)
            user!!.bestScore?.let { if(score > it) dbDAO.update(user.copy(bestScore = score)) }

            // Poi carica la classifica (ora ha i dati aggiornati)
            val users = dbDAO.getUsers()

            withContext(Dispatchers.Main) {
                layout.removeAllViews() //rimuove tutte le view duplicate
                for (u in users) {
                    val textView = TextView(requireContext())
                    textView.text = "${u.name}: ${u.bestScore} punti"
                    textView.textSize = 18f
                    layout.addView(textView)
                }
            }
        }

            val button1 = view.findViewById<Button>(R.id.buttonEnd)
            button1.setOnClickListener {
                val action = EndFragmentDirections.actionEndFragmentToNameFragment()
                findNavController().navigate(action)
            }
        }

    }


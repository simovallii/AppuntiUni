package com.example.funwithflags

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MainActivity : AppCompatActivity() {
    lateinit var dbDAO: UserDAO
    val myCoroutineScope = CoroutineScope(Dispatchers.IO)
    lateinit var countryService: CountryService
    var countriesList = listOf<CountryResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {

        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
        val retrofit = Retrofit.Builder()
            //.baseUrl("http://10.0.2.2:5000")         //it is for localhost’s requests
            .baseUrl("https://restcountries.com/")
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        countryService = retrofit.create(CountryService::class.java)

        super.onCreate(savedInstanceState)
        //creo istanza db
        dbDAO = UserDatabase.getInstance(application).getDao()

        myCoroutineScope.launch {
            try {
                countriesList = countryService.getAllCountries()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    enableEdgeToEdge()
    setContentView(R.layout.activity_main)
    ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.my_host))
    {
        v, insets ->
        val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
        insets
    }
}
}
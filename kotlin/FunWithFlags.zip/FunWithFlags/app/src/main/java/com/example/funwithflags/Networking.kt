package com.example.funwithflags

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Path


@JsonClass(generateAdapter = true)
data class CountryResponse(
    val name: Name,
    val capital: List<String>?,
    val flags: Flags
)

@JsonClass(generateAdapter = true)
data class Name(
    val common: String
)

@JsonClass(generateAdapter = true)
data class Flags(
    val png: String
)

// =======================
// MODELLO PER L'APP
// =======================



interface CountryService {

    @GET("v3.1/all?fields=name,capital,flags")
    suspend fun getAllCountries(): List<CountryResponse>

    @GET("v3.1/name/{name}")
    suspend fun getCountryByName(
        @Path("name") name: String
    ): List<CountryResponse>
}
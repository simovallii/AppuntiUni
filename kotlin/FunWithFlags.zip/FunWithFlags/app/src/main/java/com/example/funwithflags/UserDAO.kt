package com.example.funwithflags

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

//Define the DAO interface with the operations we need
@Dao
interface UserDAO {


    @Insert
    suspend fun insert(vararg u: User)

    @Update
    suspend fun update(u: User)

    @Delete
    suspend fun delete(u: User)

    @Query("SELECT bestScore FROM User WHERE username = :name")
    suspend fun getFromScore(name: String): Int

    @Query("SELECT * FROM User ORDER BY bestScore DESC")
    suspend fun getUsers(): List<User>
    @Query("SELECT * FROM User WHERE username = :name LIMIT 1")
    suspend fun getByName(name: String): User?
    @Query("DELETE FROM User")
    suspend fun deleteAll()
}

package com.example.funwithflags

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class Level3Fragment : Fragment() {

    val args: Level3FragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_level1, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val playerName = args.playerName
        var score = args.score

        // Riferimenti alle utility della MainActivity
        val mainActivity = activity as MainActivity
        val dbDAO = mainActivity.dbDAO
        val scope = mainActivity.myCoroutineScope


        // Riferimenti alle View
        val button1 = view.findViewById<Button>(R.id.button1)
        val button2 = view.findViewById<Button>(R.id.button2)
        val questionTextView = view.findViewById<TextView>(R.id.questionText)
        val ivBandiera = view.findViewById<ImageView>(R.id.flagImage)

        // Avvio coroutine su Dispatchers.IO (tramite lo scope della MainActivity)
        scope.launch {
            try {
                // 1. Recupero dati dall'API
                val countries = mainActivity.countriesList
                val countryCorrect = countries.random()
                val countryWrong = countries.filter { it.name.common != countryCorrect.name.common }.random()
                val options = listOf(countryCorrect, countryWrong).shuffled()
                val newOptions = mutableListOf<String>()
                // 2. Definizione casuale della domanda
                val questionType = (1..3).random()
                var questionText = ""
                var imageUrl: String? = null

                when (questionType) {
                    1 -> {
                        questionText = "Qual è il paese rappresentato da questa bandiera?"
                        imageUrl = countryCorrect.flags.png
                        newOptions.add(options[0].name.common)
                        newOptions.add(options[1].name.common)
                    }
                    2 -> {
                        questionText = "Qual è la capitale del paese rappresentato da questa bandiera?"
                        newOptions.add(options[0].name.common)
                        newOptions.add(options[1].name.common)
                        imageUrl = countryCorrect.flags.png
                    }
                    3 -> {
                        questionText = "Qual è la capitale di ${countryCorrect.name.common}?"
                        imageUrl = null
                        newOptions.add(options[0].capital?.get(0) ?: "Non ha capitali")
                        newOptions.add(options[1].capital?.get(0) ?: "Non ha capitali" )
                    }
                }

                // 3. Scaricamento manuale della Bitmap (solo se serve)
                val bitmap = imageUrl?.let {
                    val stream = URL(it).openStream()
                    BitmapFactory.decodeStream(stream)
                }

                // 4. Aggiornamento UI sul Main Thread
                withContext(Dispatchers.Main) {
                    questionTextView.text = questionText

                    if (bitmap != null) {
                        ivBandiera.visibility = View.VISIBLE
                        ivBandiera.setImageBitmap(bitmap)
                    } else {
                        ivBandiera.visibility = View.GONE
                    }

                    button1.text = newOptions[0]
                    button2.text = newOptions[1]


                    // Logica click Bottone 1
                    button1.setOnClickListener {
                        if (newOptions[0] == countryCorrect.name.common || newOptions[0] == countryCorrect.capital?.get(0)) score++

                        scope.launch {
                            val user = dbDAO.getByName(playerName)
                            user?.let { dbDAO.update(it.copy(score = score)) }
                            withContext(Dispatchers.Main) {
                                val action = Level3FragmentDirections.actionLevel3FragmentToEndFragment(playerName, score)
                                findNavController().navigate(action)
                            }
                        }
                    }

                    // Logica click Bottone 2
                    button2.setOnClickListener {
                        if (newOptions[1] == countryCorrect.name.common || newOptions[1] == countryCorrect.capital?.get(0)) score++

                        scope.launch {
                            val user = dbDAO.getByName(playerName)
                            user?.let { dbDAO.update(it.copy(score = score)) }
                            withContext(Dispatchers.Main) {
                                val action = Level3FragmentDirections.actionLevel3FragmentToEndFragment(playerName, score)
                                findNavController().navigate(action)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
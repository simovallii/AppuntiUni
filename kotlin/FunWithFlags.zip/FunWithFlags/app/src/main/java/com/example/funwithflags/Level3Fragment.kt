package com.example.funwithflags

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Level3Fragment : Fragment() {

    val args: Level3FragmentArgs by navArgs()

    data class Flag(val name: String, val imageRes: Int)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_level3, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val playerName = args.playerName
        var score = args.score
        val dbDAO = (activity as MainActivity).dbDAO
        val scope = (activity as MainActivity).myCoroutineScope

        val flags = listOf(
            Flag("Cina", R.drawable.china),
            Flag("Giappone", R.drawable.japan),
            Flag("Stati Uniti", R.drawable.united_states),
            Flag("Regno Unito", R.drawable.united_kingdom),
            Flag("Germania", R.drawable.germany),
            Flag("Francia", R.drawable.france),
            Flag("Belgio", R.drawable.belgium),
            Flag("Canada", R.drawable.canada),
            Flag("Cile", R.drawable.chile),
            Flag("Colombia", R.drawable.colombia),
            Flag("Polonia", R.drawable.poland),
            Flag("Russia", R.drawable.russia),
            Flag("Singapore", R.drawable.singapore),
            Flag("Vietnam", R.drawable.vietnam),
            Flag("Svezia", R.drawable.sweden)

        )

        val correctFlag = flags.random()
        val wrongFlag = flags.filter { it != correctFlag }.random()
        val options = listOf(correctFlag, wrongFlag).shuffled()

        val imageView = view.findViewById<ImageView>(R.id.flagImage)
        imageView.setImageResource(correctFlag.imageRes)

        val button1 = view.findViewById<Button>(R.id.button1)
        val button2 = view.findViewById<Button>(R.id.button2)

        button1.text = options[0].name
        button2.text = options[1].name

        button1.setOnClickListener {
            if (options[0] == correctFlag) score++

            scope.launch {
                val user = dbDAO.getByName(playerName)
                user?.let {
                    dbDAO.update(it.copy(score = score))
                }// nuovo oggetto con score modificato
                //user è una data class e non posso modificarla direttamente
                withContext(Dispatchers.Main) {
                    val action = Level3FragmentDirections.actionLevel3FragmentToEndFragment(
                        playerName,
                        score
                    )
                    findNavController().navigate(action)
                }

            }
        }

            button2.setOnClickListener {
                if (options[1] == correctFlag) score++

                scope.launch {
                    val user = dbDAO.getByName(playerName)
                    user?.let {
                        dbDAO.update(it.copy(score = score))
                    }// nuovo oggetto con score modificato
                    //user è una data class e non posso modificarla direttamente

                    withContext(Dispatchers.Main) {
                        val action = Level3FragmentDirections.actionLevel3FragmentToEndFragment(
                            playerName,
                            score
                        )
                        findNavController().navigate(action)
                    }

                }
            }

    }
}